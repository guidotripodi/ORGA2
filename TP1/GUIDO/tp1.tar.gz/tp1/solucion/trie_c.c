#include "trie.h"
#include "listaP.h"
#include <string.h>
#include <stdlib.h>

listaP *predecir_palabras(trie *t, char *teclas) { 
	int i = 0;
	listaP* listaFinal = lista_crear();
	char paraPrefijo[1024];
	char aux[1024];
	
	//incializo en ceros paraPrefijo
	int h =0;
	while(h < 1024){
		paraPrefijo[h] = '0';
		h++;
	}
	char c = 'c';
	while(teclas[i] != 0)
	{
		char* letra = caracteres_de_tecla(teclas[i]);
		paraPrefijo[i] = letra[0]; 
		aux[i] = letra[0];
		i++;
	}
	if (i == 1) //si solo hay una tecla no hago ninguna recorrida mas 
	{
		int x = 0;
		char paraPrefijo[2];
		while(caracteres_de_tecla(teclas[0])[x] != 0)
		{
			paraPrefijo[0] = caracteres_de_tecla(teclas[0])[x];
			//paraPrefijo[1] = '0';
			//prefijoletra1 = c1;
			listaP * l1 = palabras_con_prefijo(t,paraPrefijo);
			lista_concatenar(listaFinal,l1);
			x++;
		}
			
	}
	else
	{	int b = i;
		i--;
		int longitud = i; //esto me indica la longitud de mi prefijo
		int j = i; // esto indica que caracter modificar
		int k = 0; // este va a modificar el primer caracter
		i = 0;
		while( (caracteres_de_tecla(aux[0]))[k] != 0 )
		{
			paraPrefijo[j] = (caracteres_de_tecla(aux[j]))[i];
			int recorro = 0;
			char prefijoValido[b];

			//recorro el prefijo utilizado y va a prefijovalido
			while(recorro < b)
			{
				prefijoValido[recorro] = paraPrefijo[recorro];
				recorro++;
			}
			

			//lo q resta lo lleno de nulls 
			h= recorro;
			while(h < strlen(prefijoValido)){
				prefijoValido[h] = NULL ;
				h++;
			}
			


			listaP * l1 = palabras_con_prefijo(t, prefijoValido);
			lista_concatenar(listaFinal,l1);
			
			i++;		


			if( strlen(caracteres_de_tecla(aux[j])) == i )
			{
				j--;
				i = 0;
			}
			if( j == 0)
			{	
				k++;
				paraPrefijo[j] = (caracteres_de_tecla(aux[j]))[k];
				j = longitud;
			}
		}
	}
		
	return listaFinal;
}

const char *caracteres_de_tecla(char tecla){
	char* c;
	if (tecla == '1')
	{
		c = "1";
	}
	if (tecla == '2')
	{
		c = "2abc";
	}
	if (tecla == '3')
	{
		c = "3def";
	}
	if (tecla == '4')
	{
		c = "4ghi";
	}
	if (tecla == '5')
	{
		c = "5jkl";
	}
	if (tecla == '6')
	{
		c = "6mno";
	}
	if (tecla == '7')
	{
		c = "7pqrs";
	}
	if (tecla == '8')
	{
		c = "8tuv";
	}
	if (tecla == '9')
	{
		c = "9wxyz";
	}
	if (tecla == '0')
	{
		c = "0";
	}
return c;


}

double peso_palabra(char *palabra) {
	int i = 0;
	int x = 0;
	while(!(palabra[i] == 0)){
		x = x + palabra[i];
		i++;
	}
	double v = (double)x/i;
	 return v;
}



