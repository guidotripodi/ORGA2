valgrind --show-reachable=yes --leak-check=yes --error-exitcode=1 -q ./main

