#include <stdio.h>

int main(void) {


	printf("compilo y corrioooooooooooooooooooo");
    return 0;
}
